<?php
session_start();
if (!isset($_SESSION['id'])) {
    header('Location: login.php');
    exit();
}

// Подключение к базе данных
include 'application/db.php';

$userId = $_SESSION['id'];

$query = "SELECT courses.name, orders.order_date 
          FROM orders 
          JOIN courses ON orders.course_id = courses.id 
          WHERE orders.user_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $userId);
$stmt->execute();
$result = $stmt->get_result();

$orders = [];
while ($row = $result->fetch_assoc()) {
    $orders[] = $row;
}

$stmt->close();
$conn->close();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Личный кабинет - Интернет-магазин IT курсов</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <style type="text/css">
    .empty{
      height: 400px;
    }

    @media(max-width: 640px){
      .empty{
        height: 100px;
      }
    }
  </style>
  <nav class="navbar navbar-expand-lg navbar-light bg-white">
    <a class="navbar-brand" href="index.php"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php" style="color: black !important;">Главная <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="catalog.php" style="color: black !important;">Курсы</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php" style="color: black !important;">О нас</a>
        </li>
        <li class="nav-item">
          <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link" style="color: black !important;">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link" style="color: black !important;">Личный кабинет</a>';
            }
          ?>
        </li>
      </ul>
    </div>
</nav>

  <section class="container mt-5">
    <h2 class="mb-4">Личный кабинет</h2>
    <div class="row">
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title" style="font-size: 32px;">Информация о пользователе</h5>
            <p class="card-text">
              <form action="logout.php" method="post" style="font-size: 28px;">
                <p>ФИО: <span class="info" id="user-name"><?php echo
                    isset($_SESSION['login']) ? $_SESSION['login'] : ''; ?></span></p>
                <p>Возраст: <span class="info" id="user-age"><?php echo
                    isset($_SESSION['age']) ? $_SESSION['age'] : ''; ?></span></p>
                <p>Email: <span class="info" id="user-email"><?php echo
                    isset($_SESSION['email']) ? $_SESSION['email'] : ''; ?></span></p>
                <button type="submit" name="logoutButton" class="btn btn-danger">Выйти</button>
              </form>
            </p>
          </div>
        </div>
      </div>
      <div class="col-md-6">
        <div class="card">
          <div class="card-body">
            <h5 class="card-title" style="font-size: 32px;">Ваши заказы</h5>
            <div class="card-text" style="font-size: 28px;">
              <?php if (empty($orders)): ?>
                <p>У вас нет заказов.</p>
              <?php else: ?>
                <ul>
                  <?php foreach ($orders as $order): ?>
                    <li>
                      <?php echo htmlspecialchars($order['name']); ?>
                      <br>
                      <small><?php echo htmlspecialchars($order['order_date']); ?></small>
                    </li>
                  <?php endforeach; ?>
                </ul>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
  <div class="empty"> </div>
  <footer class="bg-white text-white text-center py-4 mt-5" style="color: black !important;">
    &copy; 2024 Интернет-магазин IT курсов. Все права защищены.
  </footer>


  <script src="lk.js" defer></script>
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
