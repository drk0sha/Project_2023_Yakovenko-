<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Курс ... - Интернет-магазин курсов</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  
<nav class="navbar navbar-expand-lg navbar-light bg-white">
    <a class="navbar-brand" href="index.html"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Главная</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="catalog.php">Курсы</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php">О нас</a>
        </li>
        <li class="nav-item">
          <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link">Личный кабинет</a>';
            }
          ?>
        </li>
      </ul>
    </div>
  </nav>

  <section class="container mt-5">
    <div class="row">
      <div class="col-md-8" style="font-size: 24px;">
        <h2>Курс - Основы ...</h2>
        <p>Данный курс содержит основы языка программирования .... В данном курсе будут затронуты такие темы, как ...</p>
        <p>Разделы курса:<br><strong>1.</strong> Основы синтаксиса<br><strong>2.</strong> Условия<br><strong>3.</strong> Циклы<br><strong>4.</strong> Массивы<br><strong>5.</strong> Конструкции<br><strong>6.</strong> Списки и кортежи<br><strong>7.</strong> Закрепление материала<br><strong>8.</strong> Объектно-ориентированный подход<br><strong>9.</strong> Практические задачи<br><strong>10.</strong> Библиотеки и фреймворки<br></p>
        <p>Руководителем курса является Иванов Иван - Разработчик с 10-летним стажем работы, действующий сотрудник компании Плюшкино.</p>
        <p>Длительность курса: <strong>6</strong> месяцев (<strong>200</strong> часов)</p>
        <p>Цена: <strong>50000</strong> рублей</p>
        <a href="#" class="btn btn-primary">Купить курс</a>
      </div>
      <div class="col-md-4">
        <img src="img/pl.jpg" class="img-fluid" alt="...">
      </div>
    </div>
  </section>

  <footer class="bg-white text-white text-center py-4 mt-5" style="color: black !important;">
    &copy; 2024 Интернет-магазин IT курсов. Все права защищены.
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
