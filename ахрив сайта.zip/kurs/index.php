<?php
session_start();

include("application/db.php");

$result = mysqli_query($conn, "SELECT * FROM courses LIMIT 3");

?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Интернет-магазин курсов</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
<nav class="navbar navbar-expand-lg navbar-light bg-white">
<a class="navbar-brand" href="index.php"><img src="img/logo.png"></a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item"><a class="nav-link" href="index.php" style="color: black;">Главная</a></li>
                    <li class="nav-item"><a class="nav-link" href="catalog.php" style="color: black;" >Курсы</a></li>
                    <li class="nav-item"><a class="nav-link" href="about.php" style="color: black;">О нас</a></li>
                    
                    <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link" style="color: black;">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link" style="color: black;">Личный кабинет</a>';
            }
          ?>
                </ul>
            </div>
        </nav>


  <header class="jumbotron jumbotron-fluid bg-info text-white">
    <div class="container">
      <h1 class="display-4">Добро пожаловать в наш магазин IT курсов!</h1>
      <p class="lead">Здесь вы сможете найти курсы для изучения новых языков программирования, курсы для повышения квалификации и осовения новых технологий в мире IT.</p>
    </div>
  </header>

  <section class="container mt-5">
    <h2 class="mb-4">Рекомендации для Вас</h2>
    <div class="row">
      <?php while($courses = mysqli_fetch_assoc($result)): ?>
      <div class="col-md-4 mb-4">
        <div class="card">
          <img src="<?php echo $courses['image']; ?>" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><?php echo $courses['name']; ?></h5>
            <p class="card-text"><?php echo $courses['description']; ?></p>
            <a href="<?php echo $courses['url']; ?>" class="btn btn-primary">Узнать больше</a>
          </div>
        </div>
      </div>
      <?php endwhile; ?>
    </div>
  </section>

  <footer class="bg-white text-white text-center py-4 mt-5" style="color: black !important;">
    &copy; 2024 Интернет-магазин IT курсов. Все права защищены.
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
