<?php
session_start();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Интернет-магазин IT курсов</title>
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>
<body>
  <style type="text/css">
    p{
      font-size: 24px;
    }
    .list{
      font-size: 24px;
    }
    
    @media(min-width: 700px){
      .empty{
      margin-bottom: 200px;
    }
    }
  </style>
  <nav class="navbar navbar-expand-lg navbar-light bg-white">
    <a class="navbar-brand" href="index.php"><img src="img/logo.png"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
      <ul class="navbar-nav ml-auto">
        <li class="nav-item active">
          <a class="nav-link" href="index.php" style="color: black !important;">Главная <span class="sr-only">(current)</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="catalog.php" style="color: black !important;">Курсы</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="about.php" style="color: black !important;">О нас</a>
        </li>
        <li class="nav-item">
          <?php
          if (isset($_SESSION['id'])) {
            echo '<a href="lk.php" class="nav-link" style="color: black !important;">Личный кабинет</a>';
          } else {
              echo '<a href="login.php" class="nav-link" style="color: black !important;">Личный кабинет</a>';
            }
          ?>
        </li>
      </ul>
    </div>
</nav>


  <section class="container mt-5">
    <h2 class="mb-4">О нашем магазине</h2>
    <p>В нашем интернет магазине вы сможете приобрести курсы на различные темы: языки программирования, повышение квалификации, изучение новой профессии.</p>
    <p>Наша команда состоит из опытных специалистов и преподавателей, которые постоянно следят за обновлениями в области технологий и формируют наш каталог курсов таким образом, чтобы он отвечал актуальным потребностям рынка. Сами курсы обновляются по мере появлений новых фишек и технологий, а все преподаватели имеют многолетний опыт разработки в топовых российских и зарубежных компаниях.</p>
    <p>Мы призваны помогать Вам достичь своих целей и раскрыть свой потенциал через обучение!</p>
    
  </section>

  <section class="container mt-5">
    <h2 class="mb-4">Контактная информация</h2>
    <p>Вы можете связаться с нами по следующим контактным данным:</p>
    <ul class="list">
        <li>Email: Re-Tech@gmail.com</li>
        <li>Телефон: +7 (385) 924-11-15</li>
        <li>Адрес: ул. Примерная, д. 123</li>
    </ul>
  </section>

  <div class="empty"></div>


  <footer class="bg-white text-white text-center py-4 mt-5" style="color: black !important;">
    &copy; 2024 Интернет-магазин IT курсов. Все права защищены.
  </footer>

  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.3/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>
